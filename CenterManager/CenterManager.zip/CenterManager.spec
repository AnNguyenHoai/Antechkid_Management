# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['run.py'],
    pathex=['D:\\TINHOCTRE\\10_AnTechKids_QuanLyHocSinh\\CenterManager\\src'],
    binaries=[],
    datas=[('runtime', 'runtime')],
    hiddenimports=['centermanager', 'centermanager.core', 'centermanager.database', 'centermanager.models', 'centermanager.repositories', 'centermanager.services', 'centermanager.ui', 'centermanager.export', 'centermanager.platform', 'alembic', 'sqlalchemy', 'openpyxl', 'reportlab', 'pyside6'],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='CenterManager',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    version='D:\\TINHOCTRE\\10_AnTechKids_QuanLyHocSinh\\CenterManager\\version_metadata.txt',
)
